// Funcoes
var a = 10; //por valor

const obj = { //referencia
    valor: 10
}


function calcular(valor1, valor2){
    console.log('Resultado de ${valor1} + ${valor2} é iqual a: ', valor1+valor2); 
}


function incrementeValor(valor){
    return ++valor;
}

// const incrementeValor=(valor)=>++valor; //Array function


function incrementeReferencia(objecto){
    objecto.valor++;
}
// calcular(4,7);

// incremente(a)
console.log("O valor de a é:", incrementeValor(a));
incrementeReferencia(obj)
console.log("O valor de a é:", obj);

