

for (var i = 1; i < 10; i++) {
    console.log(i % 3 == 0?i: "i:"+i)
    // if (i % 3 == 0)
    //     console.log(i)
    // else
    //     console.log("i:", i)

}

// for (var i = 3; i < 10; i+=3) {
//         console.log(i)
// }

var a =4;
var b = "4"

var c = true;
var d = "1"

if(c==d){
    console.log("A igual a B")
}else{
    console.log("A diferente de B")
}

if(a===b){
    console.log("A igual a B")
}else{
    console.log("A diferente de B")
}

