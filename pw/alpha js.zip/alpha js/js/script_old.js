let a = 5;
var b = 7;

let d = new Date().getFullYear();

for(var i=d-100; i<=d-18; i++){
    if(i%4==0){
      console.log(i)
  }
  //i=i+1;
}

if (a > b) {
  console.log(`${a} é maior que o ${b}`);
} else {
  console.log(`${b} é maior que o ${a}`);
}
console.log("Resultado", a + b);
//const c = 4

function func() {
  let a = 10; //var sobrescribe la variable anterior de si
}

func();
console.log(a);