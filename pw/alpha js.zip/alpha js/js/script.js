
const app = document.getElementById("app");
// const app = querySelector("#app");

app.style.background= "#f0f0f0"

var container = document.createElement('div');
container.className="container";
app.appendChild(container);


var divFilho = document.createElement('div');
divFilho.className="div-filho";
divFilho.style.width = "100px";
divFilho.style.height = "100px";
divFilho.style.backgroundColor = "#ff0000";
container.appendChild(divFilho);

// divFilho.onclick


const person = {
    name: "Alice",
    age: 30,
  };
const person2 = {
    ...person,
    height: 40
}

const game ={
    1: 4,
    7:6
}

const hello = val => {
    return val
};

console.log("O resultado", hello(6))
  person.height=5.5;
  
  console.log(person); 
  console.log(person2); 
