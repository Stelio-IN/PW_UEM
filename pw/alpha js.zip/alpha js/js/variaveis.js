console.log("Welcome toIntroducao ao JavaScript!");  //Mensagem será

//Variaveis tipo valor
let a = 5; //number
var nome = "John Doe"
const b= "Constante";  

//b="Variavel";

//Variaveis tipo referencia
const pessoa  = {
    nome: "Ana",
    idade: 40
}

const outraPessoa = {
    ...pessoa,
    altura: 5.5,
    peso: 85.6
};

outraPessoa.nome="Outra Ana"

//pessoa.nome = "Ana Paula";


console.log("Pessoa",pessoa)
console.log("Outra Pessoa",outraPessoa)
