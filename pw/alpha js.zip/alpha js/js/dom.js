

const app = document.getElementById('app');

app.style.width = "100px"
app.style.height = "100px"
app.style.backgroundColor = "red"


app.setAttribute("radius", "50")


const div = document.createElement("div");
div.innerHTML = "<h2>Hello World</h2>";
div.className = 'message';

app.appendChild(div)


function setStyle(){
    app.setAttribute("class", "app")
}